﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-S4MI5RU\SQLEXPRESS;Database=ProductShop;Integrated Security=True;Encrypt=false";
    }
}
