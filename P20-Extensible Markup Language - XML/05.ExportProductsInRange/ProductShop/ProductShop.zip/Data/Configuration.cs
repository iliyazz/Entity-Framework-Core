﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-S4MI5RU\SQLEXPRESS;Database=ProductShopXml;Integrated Security=True;Encrypt=False";
    }
}
