﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-S4MI5RU\SQLEXPRESS;Database=TeisterMaskExam;Integrated Security=True;Encrypt=False";
    }
}
